from .operaciones import resta, multiplica
from .traductor import traducir